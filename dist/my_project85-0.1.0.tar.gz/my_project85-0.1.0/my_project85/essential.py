import logging

# Get a logger instance for the utils module
logger = logging.getLogger(__name__)

def simple_essential_function():
    logger.debug("Running the Essential function")
    # Some Seesential operations
    logger.warning("Essential function operation completed")
