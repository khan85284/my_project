# config.py

# Define some constants
BASE_URL = 'https://httpbin.org/'
URLS_TO_SCRAPE = [
    'get',
    'status/404',
    'delay/2',
    'ip'
]
